class RunMe
{
    public static void main(String[] args)
    {
        Box orthogwnio = new Box(2.5,3.0,4.0);
        MyBox kivos = new MyBox(3.0,3.0,3.0);
        Spirtokouto spirto_kouto = new Spirtokouto(2.0,4.0,3.0,10.0);
        System.out.println(orthogwnio.toString());
        System.out.println(kivos.toString());
        System.out.println(spirto_kouto.toString());
    }
}